<?php
//
//Replace {generated_api_access_key} with your generated ACS API Key.
//Visit Accusoft Cloud Services at Accusoft.com to get your generated api key. 
//
define("ACS_API_KEY", "{generated_api_access_key}");