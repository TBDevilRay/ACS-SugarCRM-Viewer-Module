<?php

    $entry_point_registry['acsViewer'] = array(
        'file' => 'custom/modules/Accusoft/acsViewer.php',
        'auth' => true
    );